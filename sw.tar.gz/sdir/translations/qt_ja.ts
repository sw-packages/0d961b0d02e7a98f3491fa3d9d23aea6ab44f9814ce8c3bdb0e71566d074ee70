<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<dependencies>
<dependency catalog="qtbase_ja"/>
<dependency catalog="qtscript_ja"/>
<dependency catalog="qtmultimedia_ja"/>
<dependency catalog="qtxmlpatterns_ja"/>
</dependencies>
</TS>
